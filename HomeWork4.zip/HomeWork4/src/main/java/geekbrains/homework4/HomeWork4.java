package geekbrains.homework4;

public class HomeWork4 {
    //1
    // Аналогично методу в методичке, чтобы понять систему
    public static char [] [] map;
    public static final int Size = 3;
    public static final int DotToWin = 3;

    public static final char DotEmpty = '•';
    public static final char DotX = 'X';
    public static final char DotO = 'O';

    public static void initMap () {
        map = new char [Size] [Size];
        for (int i = 0; i < Size; i++) {
            for (int j = 0; j < Size; j++) {
                map [i] [j] = DotEmpty
            }
        }
    }
    public static void printMap () {
        for (int i = 0 ; i < Size; i++) {
            System.out.print (i + " ");
        }
        System.out.println();
        for (int i = 0; i < Size; i++) {
            System.out.print((i + 1) + " ");
            for (int j = 0; j < Size; j++) {
                System.out.print(map[i] [j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
    public static void main (String[] args) {
        initMap();
        printMap();
    }
    public static Scanner sc = new Scanner(System.in);
    public static void humanTurn() {
        int x, y;
        do {
            System.out.println("Введите координты в формате X Y");
            x = sc.nextInt() - 1;
            y = sc.nextInt() - 1;
        }
        while (!isCellValid(x, y));
        map[y] [x] = DotX;
    }
    public static boolean isCellValid(int x, int y) {
        if (x < 0 || x >= Size || y < 0 || y >= Size) return false;
        if (map [y] [x] == DotEmpty) return true;
        return false;
    }
    public static Random rand = new Random();
    public static void aiTurn() {
        int x, y;
        do {
            x = rand.nextInt(Size);
            y = rand.nextInt(Size);
        }
        while (!isCellValid(x, y));
        System.out.println("Компьютер заполнил поле " + (x + 1) + " " + (y +1));
        map[y] [x] = DotO;
    }
    public static boolean checkWin(char symb) {
        if(map[0][0] == symb && map[0][1] == symb && map[0][2] == symb) return true;
        if(map[1][0] == symb && map[1][1] == symb && map[1][2] == symb) return true;
        if(map[2][0] == symb && map[2][1] == symb && map[2][2] == symb) return true;
        if(map[0][0] == symb && map[1][0] == symb && map[2][0] == symb) return true;
        if(map[0][1] == symb && map[1][1] == symb && map[2][1] == symb) return true;
        if(map[0][2] == symb && map[1][2] == symb && map[2][2] == symb) return true;
        if(map[0][0] == symb && map[1][1] == symb && map[2][2] == symb) return true;
        if(map[2][0] == symb && map[1][1] == symb && map[0][2] == symb) return true;
        return false;
    }
    public staric void main (String[] args) {
        initMap();
        printMap();
        while (true) {
            humanTurn();
            printMap();
            if (checkWin(DotX)) {
                System.out.println("Победил игрок");
                break;
            }
            if (isMapFull()) {
                System.out.println("Ничья");
                break;
            }
            aiTurn();
            printMap();
            if (checkWin(DotO)) {
                System.out.println("Победил искусственный интеллект");
                break;
            }
            if (isMapFull()) {
                System.out.println("Ничья");
                break;
            }
            System.out.println("Игра закончена");
        }
    }
}
    //2, 3 Улучшение проверки метода выигрыша и попытка улучшить метод для более больших таблиц методом checkline()
    public static boolean checkWin(char symb) {
        for (int i = 0; i < Size; i++) {
            if (checkLine(i, 0, 0, 1, symb)) return true; //проверка строки
            if (checkline(0, i, 1, 0 ,symb)) return true; //проверка столбцов
            if (checkLine(0, 0, 1, 1, symb)) return true; //проверка диагоналей
            if (checkLine(0, i, 1, -1, symb)) return true;
            return false;
        }
    }
}
