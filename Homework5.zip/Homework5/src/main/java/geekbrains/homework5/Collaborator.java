package geekbrains.homework5;

/**
*Создать класс "Сотрудник" с полями: ФИО, должность, email, телефон,
 * зарплата, возраст;
*/

public class Collaborator {
    private String name;//оставляю просто имя, привычно вписывать фамилию, имя и отчество в одну строку

    private String position;
    private String email;
    private String phone;

    private Double salary;
    private int age;

    private Long inn; //номер налогоплательщика
    private String disability; //ограничения по трудоспособности
    private boolean salaryIsPrivat;

    /**
     * Конструктор класса должен заполнять эти поля при создании объекта;
     */

    public Collaborator(String name, String position, String email, String phone, Double salary, int age, Long inn, String disability, boolean salaryIsPrivat) {
        this.name = name;
        this.position = position;
        this.email = email;
        this.phone = phone;
        this.salary = salary;
        this.age = age;
        this.inn = inn;
        this.disability = disability;
        this.salaryIsPrivat = salaryIsPrivat;
    }
    public void printDetails() {
        System.out.println("Сотрудник (ФИО), " + " " + getName() +
                ", в должности: " + getPosition() + '\'' +
        "\n\temail: " + getEmail() +
                "\n\tphone: " + getPhone() +
                "\n\tВозраст: " + getAge() +
                "\n\tdisability: " + getDisability() +
                "\n\tЗаработная плата: " + getSalary() + "\n");
    }
    public String getName() {
        return  name;
    }
    public String getPosition() {
        return  position;
    }
    public String getEmail() {
        return  email;
    }
    public String getPhone() {
        return  phone;
    }
    public int getAge() {
        return  age;
    }
    public String getDisability() {
        return  disability;
    }
    public Double getSalary() {
        if (salaryIsPrivat) {
            return 0.0;
        }
        return  salary;
    }
    /**
     * Создаем массив, вывод на консоль и добавляем цикл
     */

    public  static  void main(String[] args) {
        Collaborator[] collabArray = new Collaborator[5];
        collabArray[0] = new Collaborator("Борисов Вася Александрович", "Товаровед", "borisov@yandex.ru", "13(3771)186-88-39", 63900.0, 34, 1000378644461L, "None", false);
        collabArray[1] = new Collaborator("Титов Дима Степанович", "Инфекционист", "titov@mail.ru", "23(00)739-08-31", 59000.0, 55, 1000535169829L, "None", true);
        collabArray[2] = new Collaborator("Комаров Коля Вячеславович", "Системный администратор", "komarov@gmail.com", "720(673)345-02-43", 105700.0, 46, 1000364185145L, "Грыжа", true);
        collabArray[3] = new Collaborator("Алексеев Руслан Анатольевич", "Электромонтажник", "alekseev@rambler.ru", "8(506)440-35-86", 70600.0, 28, 1000107936255L, "None", false);
        collabArray[4] = new Collaborator("Куликов Саня Яковлевич", "Фармацевт", "kulikov@l.ua", "54(6054)378-97-13", 97300.0, 50, 1000187279629L,"Слабое сердце", true);
        for(Collaborator collaborator : collabArray) {
            if (collaborator.getAge() > 40) {
                collaborator.printDetails();
            }
        }
    }
}
