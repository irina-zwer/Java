package geekbrains.homework7;

public class Cat {

    private String name;
    private int appetite;
    private boolean fed; //кот голодный

    public Cat(String name, int appetite) {
        this.name = name;
        this.appetite = appetite;
    }

    public void eat(Plate plate) {
        fed = plate.decreaseFood(this.appetite);
        System.out.println("Кот поел");
    }

    public void info() {
        System.out.println(name + " " + (fed ? " сыт " : " голоден "));
    } //смотрим сыт или голоден кот
}
