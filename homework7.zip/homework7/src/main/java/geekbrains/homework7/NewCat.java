package geekbrains.homework7;

public class NewCat {
    public static void main(String[] args) {
        Cat[] cats = {
                new Cat("Барсик", 10),
                new Cat("Мурзик", 20),
                new Cat("Матроскин", 15),
        }; //массив котов

        Plate plate = new Plate(100);
        for(Cat itemCat:cats) {
            itemCat.eat(plate);
            itemCat.info();
        } //тарелка с едой
    }
}
