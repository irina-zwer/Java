package ru.geekbrains.lesson1.homework1;

public class HomeWork1 {
    public static void main(String[] args) {

      byte a = -109;
      short b = 2020;
      int c = 55000;
      long d = 104707687134L;
      float e = 26978.3715f;
      double f = 5095875664.7175;
      char var1 = '\unicorn';
      char var2 = '666';
      char var3 = '*';
      boolean val1 = false;
      boolean val2 = true;

    }

}
