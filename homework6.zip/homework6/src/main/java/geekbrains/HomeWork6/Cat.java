package geekbrains.HomeWork6;

public class Cat extends Animal{

    public static final int CatRun = 100;
    private static final int CatJump = 25;

    private final int personalRunDelta;
    private final int personalJumpDelta;

    public Cat(int personalRunDelta, int personalJumpDelta) {
        this.personalRunDelta = personalRunDelta;
        this.personalJumpDelta = personalJumpDelta;
    }
    protected int getMaxRunLength() {
        return CatRun + personalRunDelta;
    }
    protected int getMaxJumpHeight() {
        return (CatJump + personalJumpDelta);
    }
    protected int getMaxSwimLength2() {
        return  0;
    }
}
