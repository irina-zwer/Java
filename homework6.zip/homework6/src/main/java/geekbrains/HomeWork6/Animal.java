package geekbrains.HomeWork6;

public abstract class Animal {

    protected abstract int getMaxRunLength();
    protected abstract int getMaxJumpHeight();
    protected abstract int getMaxSwimLength2();

    public void run(int length) {
        boolean canRun = length <= getMaxRunLength();
        System.out.println("Run: " + canRun);
    }

    public void jump(int height) {
        boolean canJump = height <= getMaxJumpHeight();
        System.out.println("Jump: " + canJump);
    }

    public void swim(int length2) {
        boolean canSwim = length2 <= getMaxSwimLength2();
        System.out.println("Swim: " + canSwim);
    }
}
