package geekbrains.HomeWork6;

public class Dog  extends Animal {
    private static final int DogRun = 300;
    private static final int DogJump = 65;
    private static final int DogSwim = 100;

    private final int personalRunDelta;
    private final int personalJumpDelta;
    private final int personalSwimDelta;

    public Dog(int personalRunDelta, int personalJumpDelta, int personalSwimDelta) {
        this.personalRunDelta = personalRunDelta;
        this.personalJumpDelta = personalJumpDelta;
        this.personalSwimDelta = personalSwimDelta;
    }

    protected int getMaxRunLength() {
        return DogRun + personalRunDelta;
    }

    protected int getMaxJumpHeight() {
        return (DogJump + personalJumpDelta);
    }

    protected int getMaxSwimLength2() {
        return DogSwim + personalSwimDelta;
    }
}
